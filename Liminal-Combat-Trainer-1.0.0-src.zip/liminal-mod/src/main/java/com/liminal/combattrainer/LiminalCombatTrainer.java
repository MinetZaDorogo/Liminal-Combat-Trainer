package com.liminal.combattrainer;

import com.liminal.combattrainer.client.ClientEvents;
import com.liminal.combattrainer.config.ModConfig;
import com.liminal.combattrainer.keybind.KeyBindings;
import com.liminal.combattrainer.module.CombatGuidanceModule;
import com.liminal.combattrainer.module.PvETrainingModule;
import com.liminal.combattrainer.target.TargetSelector;
import com.liminal.combattrainer.stats.TrainingStatistics;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig.Type;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLEnvironment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Liminal PvE Combat Trainer
 * Client-side mod for Minecraft 1.21.4 Forge.
 * Intended for single-player / private world PvE training only.
 */
@Mod(LiminalCombatTrainer.MOD_ID)
public class LiminalCombatTrainer {

    public static final String MOD_ID = "liminalcombat";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static CombatGuidanceModule combatGuidance;
    public static PvETrainingModule pveTraining;
    public static TargetSelector targetSelector;
    public static TrainingStatistics statistics;

    public LiminalCombatTrainer(FMLJavaModLoadingContext context) {
        IEventBus modBus = context.getModEventBus();

        // Register config
        context.registerConfig(Type.CLIENT, ModConfig.SPEC, "liminal-combat-trainer-client.toml");

        modBus.addListener(this::onClientSetup);

        if (FMLEnvironment.dist == Dist.CLIENT) {
            MinecraftForge.EVENT_BUS.register(new ClientEvents());
        }

        LOGGER.info("Liminal PvE Combat Trainer initialized (client-side)");
    }

    private void onClientSetup(final FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            KeyBindings.register();
            targetSelector = new TargetSelector();
            statistics = new TrainingStatistics();
            combatGuidance = new CombatGuidanceModule(targetSelector);
            pveTraining = new PvETrainingModule(targetSelector, statistics);
            LOGGER.info("Liminal modules loaded: CombatGuidance={}, PvETraining={}",
                    combatGuidance != null, pveTraining != null);
        });
    }
}
