package com.liminal.combattrainer.module;

import com.liminal.combattrainer.config.ModConfig;
import com.liminal.combattrainer.target.TargetSelector;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

/**
 * Combat Guidance – smooth camera assistance toward valid PvE targets.
 * Designed for training / learning aim, not for competitive advantage.
 */
public class CombatGuidanceModule {

    private final TargetSelector selector;
    private float variationPhase = 0f;

    public CombatGuidanceModule(TargetSelector selector) {
        this.selector = selector;
    }

    public void tick(Minecraft mc) {
        if (!ModConfig.guidanceEnabled) return;
        LocalPlayer player = mc.player;
        if (player == null || mc.screen != null) return;

        LivingEntity target = selector.getCurrentTarget(player);
        if (target == null) return;

        applyGuidance(player, target);
    }

    private void applyGuidance(LocalPlayer player, LivingEntity target) {
        Vec3 eye = player.getEyePosition();
        Vec3 aim = selector.getAimPoint(target);
        Vec3 dir = aim.subtract(eye).normalize();

        float targetYaw = (float) (Mth.atan2(dir.z, dir.x) * (180.0 / Math.PI)) - 90.0F;
        float targetPitch = (float) (-(Mth.atan2(dir.y, Math.sqrt(dir.x * dir.x + dir.z * dir.z)) * (180.0 / Math.PI)));

        float currentYaw = player.getYRot();
        float currentPitch = player.getXRot();

        float deltaYaw = Mth.wrapDegrees(targetYaw - currentYaw);
        float deltaPitch = targetPitch - currentPitch;

        double angle = Math.sqrt(deltaYaw * deltaYaw + deltaPitch * deltaPitch);
        if (angle < ModConfig.deadZone) return;

        // Strength + separate speeds
        float strength = (float) ModConfig.guidanceStrength;
        float hSpeed = (float) (ModConfig.horizontalSpeed * strength);
        float vSpeed = (float) (ModConfig.verticalSpeed * strength);

        // Diagonal factor
        float absYaw = Math.abs(deltaYaw);
        float absPitch = Math.abs(deltaPitch);
        if (absYaw > 0.1f && absPitch > 0.1f) {
            float diag = (float) ModConfig.diagonalResponse;
            hSpeed *= diag;
            vSpeed *= diag;
        }

        // Smooth lerp
        float smooth = (float) Mth.clamp(ModConfig.smoothness, 0.05, 0.95);
        float stepYaw = deltaYaw * (1.0f - smooth) * hSpeed * 0.15f;
        float stepPitch = deltaPitch * (1.0f - smooth) * vSpeed * 0.15f;

        // Clamp max correction per tick to avoid snaps
        stepYaw = Mth.clamp(stepYaw, -8f, 8f);
        stepPitch = Mth.clamp(stepPitch, -6f, 6f);

        // Optional variation (disabled by default)
        if (ModConfig.variationEnabled) {
            variationPhase += (float) (ModConfig.variationSpeed * 0.05);
            float var = (float) (Math.sin(variationPhase) * ModConfig.variationStrength * 0.5);
            stepYaw += var;
            stepPitch += var * 0.3f;
        }

        player.setYRot(currentYaw + stepYaw);
        player.setXRot(Mth.clamp(currentPitch + stepPitch, -90f, 90f));
    }

    public boolean isEnabled() {
        return ModConfig.guidanceEnabled;
    }
}
