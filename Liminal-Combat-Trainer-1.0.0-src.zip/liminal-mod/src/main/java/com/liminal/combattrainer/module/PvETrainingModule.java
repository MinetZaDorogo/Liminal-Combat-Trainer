package com.liminal.combattrainer.module;

import com.liminal.combattrainer.config.ModConfig;
import com.liminal.combattrainer.stats.TrainingStatistics;
import com.liminal.combattrainer.target.TargetSelector;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.InteractionHand;
import net.minecraft.network.chat.Component;

/**
 * PvE Training Actions.
 * Training Assist = visual / condition hints only (player still attacks).
 * Local Practice = limited automation only in singleplayer integrated server.
 */
public class PvETrainingModule {

    private final TargetSelector selector;
    private final TrainingStatistics stats;
    private long lastAttackMs = 0;
    private boolean lastHintShown = false;

    public PvETrainingModule(TargetSelector selector, TrainingStatistics stats) {
        this.selector = selector;
        this.stats = stats;
    }

    public void tick(Minecraft mc) {
        if (!ModConfig.trainingEnabled) return;
        LocalPlayer player = mc.player;
        if (player == null || mc.screen != null) return;

        LivingEntity target = selector.getCurrentTarget(player);
        if (target == null) {
            lastHintShown = false;
            return;
        }

        if (!isInRange(player, target)) return;
        if (ModConfig.requireLos && !player.hasLineOfSight(target)) return;
        if (ModConfig.requireWeapon && !hasWeapon(player)) return;

        // Training Assist mode – only show hints
        if (ModConfig.trainingAssistMode) {
            showAssistHint(mc, player, target);
            return;
        }

        // Local Practice – only allowed in singleplayer
        if (!isSingleplayer(mc)) {
            if (!lastHintShown) {
                player.displayClientMessage(Component.literal("§c[Liminal] Local Practice only available in singleplayer"), true);
                lastHintShown = true;
            }
            return;
        }

        // Cooldown respect
        if (ModConfig.respectCooldown && player.getAttackStrengthScale(0.5f) < 1.0f) return;

        long now = System.currentTimeMillis();
        if (now - lastAttackMs < 400) return; // basic safety throttle

        // Miss simulation for training
        if (ModConfig.missSimulation && shouldMiss()) {
            stats.recordMiss(player.distanceTo(target));
            lastAttackMs = now;
            return;
        }

        // Perform the attack (client-side swing + attack)
        player.attack(target);
        player.swing(InteractionHand.MAIN_HAND);
        stats.recordHit(player.distanceTo(target));
        lastAttackMs = now;
    }

    private void showAssistHint(Minecraft mc, LocalPlayer player, LivingEntity target) {
        if (ModConfig.requireAttackKey) {
            // Only hint when attack key is held or conditions are good
            if (!mc.options.keyAttack.isDown()) {
                lastHintShown = false;
                return;
            }
        }
        if (!lastHintShown) {
            player.displayClientMessage(
                    Component.literal("§d[Liminal] Target ready: " + target.getName().getString()),
                    true
            );
            lastHintShown = true;
        }
    }

    private boolean isInRange(LocalPlayer player, LivingEntity target) {
        return player.distanceTo(target) <= ModConfig.trainingMaxDistance;
    }

    private boolean hasWeapon(LocalPlayer player) {
        ItemStack stack = player.getMainHandItem();
        return stack.getItem() instanceof SwordItem || stack.getItem() instanceof AxeItem;
    }

    private boolean isSingleplayer(Minecraft mc) {
        return mc.hasSingleplayerServer() && mc.getSingleplayerServer() != null;
    }

    private boolean shouldMiss() {
        double chance = ModConfig.missChance / 100.0;
        if (chance <= 0) return false;
        if (chance >= 1.0) return true;
        // Simple deterministic-ish using seed if set
        long seed = ModConfig.missSeed;
        if (seed == 0) seed = System.nanoTime();
        double r = ((seed * 1103515245L + 12345L) & 0x7fffffffL) / (double) 0x7fffffffL;
        return r < chance;
    }

    public boolean isEnabled() {
        return ModConfig.trainingEnabled;
    }
}
