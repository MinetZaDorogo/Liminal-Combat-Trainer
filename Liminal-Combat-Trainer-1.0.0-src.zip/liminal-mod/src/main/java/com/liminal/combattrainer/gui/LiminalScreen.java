package com.liminal.combattrainer.gui;

import com.liminal.combattrainer.LiminalCombatTrainer;
import com.liminal.combattrainer.config.ModConfig;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.CycleButton;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

/**
 * Liminal main menu – compact dark theme with purple/blue accents.
 * Sections: Overview, Guidance, Training, Targets, Performance, Settings.
 */
public class LiminalScreen extends Screen {

    private enum Tab { OVERVIEW, GUIDANCE, TRAINING, TARGETS, PERFORMANCE, SETTINGS }
    private Tab currentTab = Tab.OVERVIEW;

    private static final int BG = 0xFF1A1A1E;
    private static final int PANEL = 0xFF2A2A30;
    private static final int ACCENT = 0xFF7B5CFF;   // purple
    private static final int ACCENT2 = 0xFF3D8BFF;  // electric blue
    private static final int TEXT = 0xFFE0E0E8;
    private static final int DIM = 0xFF8888A0;

    public LiminalScreen() {
        super(Component.literal("Liminal"));
    }

    @Override
    protected void init() {
        clearWidgets();
        int left = 20;
        int top = 40;
        int btnW = 90;
        int btnH = 18;
        int gap = 4;

        // Tab buttons
        addRenderableWidget(Button.builder(Component.literal("Overview"), b -> switchTab(Tab.OVERVIEW))
                .bounds(left, top, btnW, btnH).build());
        addRenderableWidget(Button.builder(Component.literal("Guidance"), b -> switchTab(Tab.GUIDANCE))
                .bounds(left + (btnW + gap), top, btnW, btnH).build());
        addRenderableWidget(Button.builder(Component.literal("Training"), b -> switchTab(Tab.TRAINING))
                .bounds(left + 2 * (btnW + gap), top, btnW, btnH).build());
        addRenderableWidget(Button.builder(Component.literal("Targets"), b -> switchTab(Tab.TARGETS))
                .bounds(left + 3 * (btnW + gap), top, btnW, btnH).build());
        addRenderableWidget(Button.builder(Component.literal("Perf"), b -> switchTab(Tab.PERFORMANCE))
                .bounds(left + 4 * (btnW + gap), top, 60, btnH).build());
        addRenderableWidget(Button.builder(Component.literal("Settings"), b -> switchTab(Tab.SETTINGS))
                .bounds(left + 5 * (btnW + gap) - 30, top, 70, btnH).build());

        int y = 70;
        int panelLeft = 20;
        int sliderW = Math.min(280, this.width - 60);

        switch (currentTab) {
            case OVERVIEW -> buildOverview(panelLeft, y);
            case GUIDANCE -> buildGuidance(panelLeft, y, sliderW);
            case TRAINING -> buildTraining(panelLeft, y, sliderW);
            case TARGETS -> buildTargets(panelLeft, y);
            case PERFORMANCE -> buildPerformance(panelLeft, y, sliderW);
            case SETTINGS -> buildSettings(panelLeft, y);
        }

        // Close button
        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(this.width - 80, this.height - 28, 60, 18).build());
    }

    private void switchTab(Tab tab) {
        currentTab = tab;
        init();
    }

    private void buildOverview(int x, int y) {
        // Status is drawn in render
    }

    private void buildGuidance(int x, int y, int w) {
        addRenderableWidget(CycleButton.onOffBuilder(ModConfig.guidanceEnabled)
                .create(x, y, 160, 18, Component.literal("Guidance Enabled"),
                        (btn, val) -> {
                            ModConfig.GUIDANCE_ENABLED.set(val);
                            ModConfig.guidanceEnabled = val;
                        }));
        y += 24;

        addRenderableWidget(new SimpleSlider(x, y, w, 18, "Strength", ModConfig.guidanceStrength, 0, 1,
                v -> { ModConfig.GUIDANCE_STRENGTH.set(v); ModConfig.guidanceStrength = v; }));
        y += 22;
        addRenderableWidget(new SimpleSlider(x, y, w, 18, "H-Speed", ModConfig.horizontalSpeed, 0.01, 5,
                v -> { ModConfig.HORIZONTAL_SPEED.set(v); ModConfig.horizontalSpeed = v; }));
        y += 22;
        addRenderableWidget(new SimpleSlider(x, y, w, 18, "V-Speed", ModConfig.verticalSpeed, 0.01, 5,
                v -> { ModConfig.VERTICAL_SPEED.set(v); ModConfig.verticalSpeed = v; }));
        y += 22;
        addRenderableWidget(new SimpleSlider(x, y, w, 18, "Smoothness", ModConfig.smoothness, 0, 1,
                v -> { ModConfig.SMOOTHNESS.set(v); ModConfig.smoothness = v; }));
        y += 22;
        addRenderableWidget(new SimpleSlider(x, y, w, 18, "Max Angle", ModConfig.maxAngle, 5, 180,
                v -> { ModConfig.MAX_ANGLE.set(v); ModConfig.maxAngle = v; }));
        y += 22;
        addRenderableWidget(new SimpleSlider(x, y, w, 18, "Max Distance", ModConfig.maxDistance, 1, 64,
                v -> { ModConfig.MAX_DISTANCE.set(v); ModConfig.maxDistance = v; }));
        y += 22;
        addRenderableWidget(new SimpleSlider(x, y, w, 18, "Dead Zone", ModConfig.deadZone, 0, 30,
                v -> { ModConfig.DEAD_ZONE.set(v); ModConfig.deadZone = v; }));
    }

    private void buildTraining(int x, int y, int w) {
        addRenderableWidget(CycleButton.onOffBuilder(ModConfig.trainingEnabled)
                .create(x, y, 160, 18, Component.literal("Training Enabled"),
                        (btn, val) -> {
                            ModConfig.TRAINING_ENABLED.set(val);
                            ModConfig.trainingEnabled = val;
                        }));
        y += 24;
        addRenderableWidget(CycleButton.onOffBuilder(ModConfig.trainingAssistMode)
                .withValues(true, false)
                .withInitialValue(ModConfig.trainingAssistMode)
                .create(x, y, 200, 18, Component.literal("Mode"),
                        (btn, val) -> {
                            ModConfig.TRAINING_ASSIST_MODE.set(val);
                            ModConfig.trainingAssistMode = val;
                        }));
        // Note: CycleButton for boolean shows On/Off; we treat true=Assist
        y += 24;
        addRenderableWidget(new SimpleSlider(x, y, w, 18, "Max Distance", ModConfig.trainingMaxDistance, 1, 16,
                v -> { ModConfig.TRAINING_MAX_DISTANCE.set(v); ModConfig.trainingMaxDistance = v; }));
        y += 22;
        addRenderableWidget(CycleButton.onOffBuilder(ModConfig.requireLos)
                .create(x, y, 160, 18, Component.literal("Require LoS"),
                        (btn, val) -> { ModConfig.REQUIRE_LINE_OF_SIGHT.set(val); ModConfig.requireLos = val; }));
        y += 22;
        addRenderableWidget(CycleButton.onOffBuilder(ModConfig.respectCooldown)
                .create(x, y, 180, 18, Component.literal("Respect Cooldown"),
                        (btn, val) -> { ModConfig.RESPECT_VANILLA_COOLDOWN.set(val); ModConfig.respectCooldown = val; }));
        y += 22;
        addRenderableWidget(CycleButton.onOffBuilder(ModConfig.missSimulation)
                .create(x, y, 160, 18, Component.literal("Miss Simulation"),
                        (btn, val) -> { ModConfig.MISS_SIMULATION.set(val); ModConfig.missSimulation = val; }));
        y += 22;
        addRenderableWidget(new SimpleSlider(x, y, w, 18, "Miss Chance %", ModConfig.missChance, 0, 100,
                v -> { ModConfig.MISS_CHANCE.set(v); ModConfig.missChance = v; }));
        y += 28;
        addRenderableWidget(Button.builder(Component.literal("Reset Statistics"), b -> {
            if (LiminalCombatTrainer.statistics != null) LiminalCombatTrainer.statistics.reset();
        }).bounds(x, y, 140, 18).build());
    }

    private void buildTargets(int x, int y) {
        addRenderableWidget(CycleButton.onOffBuilder(ModConfig.filterHostile)
                .create(x, y, 160, 18, Component.literal("Hostile Mobs"),
                        (btn, val) -> { ModConfig.FILTER_HOSTILE.set(val); ModConfig.filterHostile = val; }));
        y += 22;
        addRenderableWidget(CycleButton.onOffBuilder(ModConfig.filterPassive)
                .create(x, y, 160, 18, Component.literal("Passive Mobs"),
                        (btn, val) -> { ModConfig.FILTER_PASSIVE.set(val); ModConfig.filterPassive = val; }));
        y += 22;
        addRenderableWidget(CycleButton.onOffBuilder(ModConfig.filterNeutral)
                .create(x, y, 160, 18, Component.literal("Neutral Mobs"),
                        (btn, val) -> { ModConfig.FILTER_NEUTRAL.set(val); ModConfig.filterNeutral = val; }));
        y += 22;
        addRenderableWidget(CycleButton.onOffBuilder(ModConfig.filterDummy)
                .create(x, y, 160, 18, Component.literal("Training Dummy"),
                        (btn, val) -> { ModConfig.FILTER_DUMMY.set(val); ModConfig.filterDummy = val; }));
    }

    private void buildPerformance(int x, int y, int w) {
        addRenderableWidget(CycleButton.onOffBuilder(ModConfig.animationsEnabled)
                .create(x, y, 160, 18, Component.literal("Animations"),
                        (btn, val) -> { ModConfig.ANIMATIONS_ENABLED.set(val); ModConfig.animationsEnabled = val; }));
        y += 22;
        addRenderableWidget(new SimpleSlider(x, y, w, 18, "Update Rate ms", ModConfig.updateRateMs, 16, 200,
                v -> {
                    int iv = (int) Math.round(v);
                    ModConfig.UPDATE_RATE_MS.set(iv);
                    ModConfig.updateRateMs = iv;
                }));
    }

    private void buildSettings(int x, int y) {
        addRenderableWidget(Button.builder(Component.literal("Reload Config"), b -> ModConfig.reload())
                .bounds(x, y, 140, 18).build());
        y += 24;
        addRenderableWidget(Button.builder(Component.literal("Reset All Defaults"), b -> {
            // Simple reset via defaults – full reset would require more work
            ModConfig.GUIDANCE_ENABLED.set(false);
            ModConfig.TRAINING_ENABLED.set(false);
            ModConfig.reload();
            init();
        }).bounds(x, y, 160, 18).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partial) {
        // Dark background
        g.fill(0, 0, this.width, this.height, BG);
        // Top bar
        g.fill(0, 0, this.width, 32, PANEL);
        g.drawString(this.font, "§dLiminal §7PvE Combat Trainer", 12, 10, TEXT, false);

        // Content panel
        g.fill(12, 62, this.width - 12, this.height - 36, PANEL);

        if (currentTab == Tab.OVERVIEW) {
            int y = 78;
            g.drawString(this.font, "§7Status", 24, y, DIM, false);
            y += 14;
            boolean gEn = ModConfig.guidanceEnabled;
            boolean tEn = ModConfig.trainingEnabled;
            g.drawString(this.font, "Combat Guidance: " + (gEn ? "§aON" : "§cOFF"), 24, y, TEXT, false);
            y += 12;
            g.drawString(this.font, "PvE Training: " + (tEn ? "§aON" : "§cOFF") +
                    (tEn ? (ModConfig.trainingAssistMode ? " §7(Assist)" : " §e(Local Practice)") : ""), 24, y, TEXT, false);
            y += 18;
            if (LiminalCombatTrainer.statistics != null) {
                g.drawString(this.font, "§7Statistics", 24, y, DIM, false);
                y += 14;
                g.drawString(this.font, LiminalCombatTrainer.statistics.getSummary(), 24, y, TEXT, false);
            }
            y += 24;
            g.drawString(this.font, "§8Right Shift – open/close menu", 24, y, DIM, false);
            y += 12;
            g.drawString(this.font, "§8Client-side only • Singleplayer / private worlds", 24, y, DIM, false);
        }

        super.render(g, mouseX, mouseY, partial);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        // Config is written by Forge automatically on change for most values;
        // force a save if needed in future.
        super.onClose();
    }

    /** Simple double slider */
    private static class SimpleSlider extends AbstractSliderButton {
        private final String label;
        private final double min, max;
        private final java.util.function.DoubleConsumer onChange;

        public SimpleSlider(int x, int y, int w, int h, String label, double value, double min, double max,
                            java.util.function.DoubleConsumer onChange) {
            super(x, y, w, h, Component.empty(), (value - min) / (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.onChange = onChange;
            updateMessage();
        }

        @Override
        protected void updateMessage() {
            double v = min + this.value * (max - min);
            this.setMessage(Component.literal(label + ": " + String.format("%.2f", v)));
        }

        @Override
        protected void applyValue() {
            double v = min + this.value * (max - min);
            onChange.accept(v);
        }
    }
}
