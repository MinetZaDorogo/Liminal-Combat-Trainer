package com.liminal.combattrainer.stats;

/**
 * Training accuracy statistics.
 * Tracks attempts, hits, artificial misses, average distance and timing.
 */
public class TrainingStatistics {

    private int attempts = 0;
    private int hits = 0;
    private int artificialMisses = 0;
    private double totalDistance = 0.0;
    private long lastAttemptMs = 0;
    private long totalIntervalMs = 0;
    private int intervalCount = 0;

    public void recordHit(double distance) {
        attempts++;
        hits++;
        totalDistance += distance;
        updateInterval();
    }

    public void recordMiss(double distance) {
        attempts++;
        artificialMisses++;
        totalDistance += distance;
        updateInterval();
    }

    private void updateInterval() {
        long now = System.currentTimeMillis();
        if (lastAttemptMs > 0) {
            totalIntervalMs += (now - lastAttemptMs);
            intervalCount++;
        }
        lastAttemptMs = now;
    }

    public void reset() {
        attempts = 0;
        hits = 0;
        artificialMisses = 0;
        totalDistance = 0.0;
        lastAttemptMs = 0;
        totalIntervalMs = 0;
        intervalCount = 0;
    }

    public int getAttempts() { return attempts; }
    public int getHits() { return hits; }
    public int getArtificialMisses() { return artificialMisses; }

    public double getHitPercent() {
        if (attempts == 0) return 0.0;
        return (hits * 100.0) / attempts;
    }

    public double getAverageDistance() {
        if (attempts == 0) return 0.0;
        return totalDistance / attempts;
    }

    public double getAverageIntervalMs() {
        if (intervalCount == 0) return 0.0;
        return (double) totalIntervalMs / intervalCount;
    }

    public String getSummary() {
        return String.format(
                "Attempts: %d | Hits: %d | Misses: %d | Accuracy: %.1f%% | Avg Dist: %.1f | Avg Interval: %.0fms",
                attempts, hits, artificialMisses, getHitPercent(), getAverageDistance(), getAverageIntervalMs()
        );
    }
}
