package com.liminal.combattrainer.client;

import com.liminal.combattrainer.LiminalCombatTrainer;
import com.liminal.combattrainer.config.ModConfig;
import com.liminal.combattrainer.gui.LiminalScreen;
import com.liminal.combattrainer.keybind.KeyBindings;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Client-side event handlers.
 */
@Mod.EventBusSubscriber(modid = LiminalCombatTrainer.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class ClientEvents {

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        if (LiminalCombatTrainer.combatGuidance != null) {
            LiminalCombatTrainer.combatGuidance.tick(mc);
        }
        if (LiminalCombatTrainer.pveTraining != null) {
            LiminalCombatTrainer.pveTraining.tick(mc);
        }
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.Key event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        if (KeyBindings.OPEN_MENU != null && KeyBindings.OPEN_MENU.consumeClick()) {
            if (mc.screen instanceof LiminalScreen) {
                mc.setScreen(null);
            } else {
                mc.setScreen(new LiminalScreen());
            }
        }
    }
}

/**
 * Separate subscriber for mod bus (key registration).
 */
@Mod.EventBusSubscriber(modid = LiminalCombatTrainer.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
class ClientModEvents {
    @SubscribeEvent
    public static void onRegisterKeys(RegisterKeyMappingsEvent event) {
        if (KeyBindings.OPEN_MENU != null) {
            event.register(KeyBindings.OPEN_MENU);
        }
    }
}
