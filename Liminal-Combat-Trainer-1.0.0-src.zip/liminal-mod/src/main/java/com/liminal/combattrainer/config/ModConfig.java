package com.liminal.combattrainer.config;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.config.ModConfigEvent;
import com.liminal.combattrainer.LiminalCombatTrainer;

/**
 * Client configuration for Liminal PvE Combat Trainer.
 * All settings are client-side only.
 */
@Mod.EventBusSubscriber(modid = LiminalCombatTrainer.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModConfig {

    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();

    // ===== Combat Guidance =====
    public static final ForgeConfigSpec.BooleanValue GUIDANCE_ENABLED;
    public static final ForgeConfigSpec.DoubleValue GUIDANCE_STRENGTH;
    public static final ForgeConfigSpec.DoubleValue HORIZONTAL_SPEED;
    public static final ForgeConfigSpec.DoubleValue VERTICAL_SPEED;
    public static final ForgeConfigSpec.DoubleValue DIAGONAL_RESPONSE;
    public static final ForgeConfigSpec.DoubleValue SMOOTHNESS;
    public static final ForgeConfigSpec.DoubleValue MAX_ANGLE;
    public static final ForgeConfigSpec.DoubleValue MAX_DISTANCE;
    public static final ForgeConfigSpec.ConfigValue<String> TARGET_POINT;
    public static final ForgeConfigSpec.DoubleValue DEAD_ZONE;
    public static final ForgeConfigSpec.BooleanValue VARIATION_ENABLED;
    public static final ForgeConfigSpec.DoubleValue VARIATION_STRENGTH;
    public static final ForgeConfigSpec.DoubleValue VARIATION_SPEED;

    // ===== PvE Training =====
    public static final ForgeConfigSpec.BooleanValue TRAINING_ENABLED;
    public static final ForgeConfigSpec.BooleanValue TRAINING_ASSIST_MODE; // true = visual only, false = Local Practice
    public static final ForgeConfigSpec.DoubleValue TRAINING_MAX_DISTANCE;
    public static final ForgeConfigSpec.BooleanValue REQUIRE_LINE_OF_SIGHT;
    public static final ForgeConfigSpec.BooleanValue REQUIRE_CROSSHAIR;
    public static final ForgeConfigSpec.BooleanValue REQUIRE_ATTACK_KEY;
    public static final ForgeConfigSpec.BooleanValue REQUIRE_WEAPON;
    public static final ForgeConfigSpec.BooleanValue RESPECT_VANILLA_COOLDOWN;
    public static final ForgeConfigSpec.BooleanValue MISS_SIMULATION;
    public static final ForgeConfigSpec.DoubleValue MISS_CHANCE;
    public static final ForgeConfigSpec.LongValue MISS_SEED;

    // ===== Target Filters =====
    public static final ForgeConfigSpec.BooleanValue FILTER_HOSTILE;
    public static final ForgeConfigSpec.BooleanValue FILTER_PASSIVE;
    public static final ForgeConfigSpec.BooleanValue FILTER_NEUTRAL;
    public static final ForgeConfigSpec.BooleanValue FILTER_DUMMY;

    // ===== Performance / GUI =====
    public static final ForgeConfigSpec.BooleanValue ANIMATIONS_ENABLED;
    public static final ForgeConfigSpec.DoubleValue GUI_SCALE;
    public static final ForgeConfigSpec.IntValue UPDATE_RATE_MS;

    static {
        BUILDER.comment("Combat Guidance - camera assist for PvE training").push("combat_guidance");
        GUIDANCE_ENABLED = BUILDER.comment("Enable Combat Guidance").define("enabled", false);
        GUIDANCE_STRENGTH = BUILDER.comment("Overall guidance strength (0.0 - 1.0)").defineInRange("strength", 0.4, 0.0, 1.0);
        HORIZONTAL_SPEED = BUILDER.comment("Horizontal correction speed").defineInRange("horizontal_speed", 0.5, 0.01, 5.0);
        VERTICAL_SPEED = BUILDER.comment("Vertical correction speed").defineInRange("vertical_speed", 0.4, 0.01, 5.0);
        DIAGONAL_RESPONSE = BUILDER.comment("Diagonal response factor").defineInRange("diagonal_response", 0.7, 0.0, 2.0);
        SMOOTHNESS = BUILDER.comment("Camera smoothness (higher = smoother)").defineInRange("smoothness", 0.6, 0.0, 1.0);
        MAX_ANGLE = BUILDER.comment("Maximum search angle in degrees").defineInRange("max_angle", 45.0, 5.0, 180.0);
        MAX_DISTANCE = BUILDER.comment("Maximum target distance in blocks").defineInRange("max_distance", 12.0, 1.0, 64.0);
        TARGET_POINT = BUILDER.comment("Target point: HEAD, BODY, CENTER").define("target_point", "HEAD");
        DEAD_ZONE = BUILDER.comment("Dead zone angle (no correction inside)").defineInRange("dead_zone", 2.0, 0.0, 30.0);
        VARIATION_ENABLED = BUILDER.comment("Enable optional visual variation (off by default)").define("variation_enabled", false);
        VARIATION_STRENGTH = BUILDER.comment("Variation intensity").defineInRange("variation_strength", 0.1, 0.0, 1.0);
        VARIATION_SPEED = BUILDER.comment("Variation change speed").defineInRange("variation_speed", 0.5, 0.01, 5.0);
        BUILDER.pop();

        BUILDER.comment("PvE Training Actions").push("pve_training");
        TRAINING_ENABLED = BUILDER.comment("Enable PvE Training module").define("enabled", false);
        TRAINING_ASSIST_MODE = BUILDER.comment("true = Training Assist (visual hints only), false = Local Practice (singleplayer only)").define("assist_mode", true);
        TRAINING_MAX_DISTANCE = BUILDER.comment("Max distance for training actions").defineInRange("max_distance", 6.0, 1.0, 16.0);
        REQUIRE_LINE_OF_SIGHT = BUILDER.comment("Require line of sight").define("require_los", true);
        REQUIRE_CROSSHAIR = BUILDER.comment("Require crosshair on target").define("require_crosshair", false);
        REQUIRE_ATTACK_KEY = BUILDER.comment("Require attack key press for assist").define("require_attack_key", true);
        REQUIRE_WEAPON = BUILDER.comment("Require a weapon in hand").define("require_weapon", false);
        RESPECT_VANILLA_COOLDOWN = BUILDER.comment("Respect vanilla attack cooldown").define("respect_cooldown", true);
        MISS_SIMULATION = BUILDER.comment("Enable artificial miss simulation for training stats").define("miss_simulation", false);
        MISS_CHANCE = BUILDER.comment("Miss chance percent (0-100)").defineInRange("miss_chance", 0.0, 0.0, 100.0);
        MISS_SEED = BUILDER.comment("Optional seed for reproducible miss tests (0 = random)").defineInRange("miss_seed", 0L, 0L, Long.MAX_VALUE);
        BUILDER.pop();

        BUILDER.comment("Target filters").push("targets");
        FILTER_HOSTILE = BUILDER.comment("Allow hostile mobs").define("hostile", true);
        FILTER_PASSIVE = BUILDER.comment("Allow passive mobs").define("passive", false);
        FILTER_NEUTRAL = BUILDER.comment("Allow neutral mobs").define("neutral", true);
        FILTER_DUMMY = BUILDER.comment("Allow training dummies if present").define("dummy", true);
        BUILDER.pop();

        BUILDER.comment("Performance and GUI").push("performance");
        ANIMATIONS_ENABLED = BUILDER.comment("Enable GUI animations").define("animations", true);
        GUI_SCALE = BUILDER.comment("GUI scale multiplier").defineInRange("gui_scale", 1.0, 0.5, 2.0);
        UPDATE_RATE_MS = BUILDER.comment("Target selection update interval (ms)").defineInRange("update_rate_ms", 50, 16, 200);
        BUILDER.pop();
    }

    public static final ForgeConfigSpec SPEC = BUILDER.build();

    // Cached values (updated on load/reload)
    public static boolean guidanceEnabled;
    public static double guidanceStrength;
    public static double horizontalSpeed;
    public static double verticalSpeed;
    public static double diagonalResponse;
    public static double smoothness;
    public static double maxAngle;
    public static double maxDistance;
    public static String targetPoint;
    public static double deadZone;
    public static boolean variationEnabled;
    public static double variationStrength;
    public static double variationSpeed;

    public static boolean trainingEnabled;
    public static boolean trainingAssistMode;
    public static double trainingMaxDistance;
    public static boolean requireLos;
    public static boolean requireCrosshair;
    public static boolean requireAttackKey;
    public static boolean requireWeapon;
    public static boolean respectCooldown;
    public static boolean missSimulation;
    public static double missChance;
    public static long missSeed;

    public static boolean filterHostile;
    public static boolean filterPassive;
    public static boolean filterNeutral;
    public static boolean filterDummy;

    public static boolean animationsEnabled;
    public static double guiScale;
    public static int updateRateMs;

    @SubscribeEvent
    static void onLoad(final ModConfigEvent event) {
        if (event.getConfig().getSpec() != SPEC) return;
        reload();
    }

    public static void reload() {
        guidanceEnabled = GUIDANCE_ENABLED.get();
        guidanceStrength = GUIDANCE_STRENGTH.get();
        horizontalSpeed = HORIZONTAL_SPEED.get();
        verticalSpeed = VERTICAL_SPEED.get();
        diagonalResponse = DIAGONAL_RESPONSE.get();
        smoothness = SMOOTHNESS.get();
        maxAngle = MAX_ANGLE.get();
        maxDistance = MAX_DISTANCE.get();
        targetPoint = TARGET_POINT.get();
        deadZone = DEAD_ZONE.get();
        variationEnabled = VARIATION_ENABLED.get();
        variationStrength = VARIATION_STRENGTH.get();
        variationSpeed = VARIATION_SPEED.get();

        trainingEnabled = TRAINING_ENABLED.get();
        trainingAssistMode = TRAINING_ASSIST_MODE.get();
        trainingMaxDistance = TRAINING_MAX_DISTANCE.get();
        requireLos = REQUIRE_LINE_OF_SIGHT.get();
        requireCrosshair = REQUIRE_CROSSHAIR.get();
        requireAttackKey = REQUIRE_ATTACK_KEY.get();
        requireWeapon = REQUIRE_WEAPON.get();
        respectCooldown = RESPECT_VANILLA_COOLDOWN.get();
        missSimulation = MISS_SIMULATION.get();
        missChance = MISS_CHANCE.get();
        missSeed = MISS_SEED.get();

        filterHostile = FILTER_HOSTILE.get();
        filterPassive = FILTER_PASSIVE.get();
        filterNeutral = FILTER_NEUTRAL.get();
        filterDummy = FILTER_DUMMY.get();

        animationsEnabled = ANIMATIONS_ENABLED.get();
        guiScale = GUI_SCALE.get();
        updateRateMs = UPDATE_RATE_MS.get();
    }
}
