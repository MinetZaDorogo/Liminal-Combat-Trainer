package com.liminal.combattrainer.keybind;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

/**
 * Keybind registration for Liminal menu.
 * Default: Right Shift
 */
public class KeyBindings {

    public static final String CATEGORY = "key.categories.liminalcombat";

    public static KeyMapping OPEN_MENU;

    public static void register() {
        OPEN_MENU = new KeyMapping(
                "key.liminalcombat.open_menu",
                KeyConflictContext.IN_GAME,
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                CATEGORY
        );
        // Registration happens via RegisterKeyMappingsEvent in ClientEvents
    }
}
