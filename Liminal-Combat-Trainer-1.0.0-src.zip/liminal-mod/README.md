# Liminal PvE Combat Trainer

**Client-side PvE combat trainer for Minecraft Java Edition 1.21.4 + Forge**

Designed for single-player and private worlds.  
Modules provide camera guidance assistance and training actions against mobs for learning combat mechanics.

**Not intended for PvP, public servers, or gaining advantage over other players.**

---

## Features (implemented in this build)

### Module A — Combat Guidance
- Toggleable camera assist toward valid mob targets
- Configurable strength, horizontal/vertical speed, smoothness
- Max angle / max distance / dead zone
- Target point: HEAD / BODY / CENTER
- Optional visual variation (disabled by default)
- Settings via GUI sliders + Forge config

### Module B — PvE Training Actions
- **Training Assist** (default): visual hints when conditions are good; player still performs the attack
- **Local Practice**: limited automation — **only works in singleplayer** (integrated server check)
- Filters: require LoS, respect vanilla attack cooldown, require weapon, etc.
- Artificial miss simulation for training statistics (0–100%)
- Statistics: attempts, hits, artificial misses, accuracy %, average distance, average interval

### Shared
- Target Selection with category filters (Hostile / Passive / Neutral / Dummy)
- Limited update rate + caching (Android-friendly)
- Keybind: **Right Shift** opens/closes the Liminal menu
- Config saved as `liminal-combat-trainer-client.toml`
- Client-side only (`clientSideOnly=true`)

### GUI — Liminal
- Dark graphite/black theme with purple & electric-blue accents
- Tabs: Overview · Guidance · Training · Targets · Perf · Settings
- Sliders + cycle buttons, compact layout suitable for smaller screens

---

## Requirements

| Component          | Version          |
|--------------------|------------------|
| Minecraft          | 1.21.4           |
| Forge              | 54.1.x (tested against 54.1.18) |
| Java               | 21               |
| ForgeGradle        | 7.x              |

---

## Building from source

1. Install **JDK 21**.
2. Clone / copy this project.
3. Run:
   ```bash
   ./gradlew build
   ```
4. Output JAR:
   ```
   build/libs/Liminal-Combat-Trainer-1.0.0.jar
   ```

**Note:** First build downloads Minecraft + Forge mappings and needs several GB of RAM and disk.  
The environment used to prepare this source had only ~1.2 GB RAM, so the Gradle daemon was killed during mapping processing. You must build on a machine with adequate memory (≥4–6 GB free recommended).

---

## Installation (Desktop)

1. Install Forge 1.21.4.
2. Place `Liminal-Combat-Trainer-1.0.0.jar` into the `mods` folder.
3. Launch Minecraft.
4. Press **Right Shift** in-game to open the menu.

## Installation via FoldCraft Launcher (Android)

1. Install FoldCraft Launcher and set up a Minecraft 1.21.4 + Forge instance.
2. Copy the JAR into the instance `mods` directory (or use the launcher’s mod manager).
3. Allocate reasonable memory (FoldCraft / Pojav / similar launchers usually need careful RAM settings on mobile).
4. Launch and open the menu with the assigned key (Right Shift by default; may need rebinding on touch layouts).

Touch / on-screen keyboard support depends on the launcher. The GUI is compact and should work with scaled interfaces.

---

## Configuration

File (created on first run):

```
config/liminal-combat-trainer-client.toml
```

All options are also editable live in the in-game Liminal menu.  
Changes to most values apply immediately; config is persisted by Forge.

---

## Known limitations / status of this source package

| Item | Status |
|------|--------|
| Project structure & packages | Complete |
| Forge config system | Complete |
| Keybind registration | Complete |
| Target selection + caching | Complete |
| Combat Guidance logic | Complete (basic smooth assist) |
| PvE Training Assist + Local Practice (SP only) | Complete |
| Training statistics | Complete |
| Liminal GUI (tabs, sliders, toggles) | Functional basic version |
| Full visual polish / animations | Minimal |
| Advanced diagonal/variation tuning | Present but basic |
| Full Gradle build in this environment | **Failed** (insufficient RAM) |
| Runtime testing in Minecraft | **Not performed** (no client available) |
| Android-specific input / scaling polish | Not tested |

The code is real, uses official Forge events and APIs, and contains no packet spoofing or anti-cheat bypasses.  
Local Practice is hard-gated behind `mc.hasSingleplayerServer()`.

---

## Architecture

```
com.liminal.combattrainer
├── LiminalCombatTrainer      – mod entry
├── config.ModConfig          – ForgeConfigSpec + cached values
├── keybind.KeyBindings
├── target.TargetSelector     – shared targeting
├── module.CombatGuidanceModule
├── module.PvETrainingModule
├── stats.TrainingStatistics
├── client.ClientEvents       – tick + key handling
└── gui.LiminalScreen         – main menu
```

---

## Disclaimer

This mod is provided for personal PvE training and experimentation in single-player / private worlds only.  
The authors do not endorse using any assist or automation features on public multiplayer servers.  
Use at your own risk; many servers prohibit client-side combat assistance.

---

## License

All Rights Reserved (as stated in mods.toml).  
Modify and use for personal purposes.
